#include <ArduTFLite.h>
#include "model.h"

constexpr int kTensorArenaSize = 5000;

alignas(16) uint8_t tensor_arena[kTensorArenaSize];

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("================================");
  Serial.println("     TFLITE MICRO INFERENCE");
  Serial.println("================================");

  if (!modelInit(model, tensor_arena, kTensorArenaSize)) {
    Serial.println("Model initialization FAILED!");
    while (1);
  }

  Serial.println("Model loaded successfully!");
  Serial.println();
}

void loop() {
  // Sample input
  float input = 0.50;

  Serial.print("Input: ");
  Serial.println(input, 2);

  modelSetInput(input, 0);

  if (!modelRunInference()) {
    Serial.println("Inference FAILED!");
    delay(2000);
    return;
  }

  float dark   = modelGetOutput(0);
  float normal = modelGetOutput(1);
  float bright = modelGetOutput(2);

  Serial.print("Dark:   ");
  Serial.println(dark, 4);

  Serial.print("Normal: ");
  Serial.println(normal, 4);

  Serial.print("Bright: ");
  Serial.println(bright, 4);

  int predictedClass = 0;

  if (normal > dark && normal > bright)
    predictedClass = 1;
  else if (bright > dark && bright > normal)
    predictedClass = 2;

  Serial.print("Predicted Class: ");

  if (predictedClass == 0)
    Serial.println("Dark");
  else if (predictedClass == 1)
    Serial.println("Normal");
  else
    Serial.println("Bright");

  Serial.println("-------------------------------");

  delay(3000);
}